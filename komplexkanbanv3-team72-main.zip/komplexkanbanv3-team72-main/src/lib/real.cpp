#include "Complex.hpp"
using namespace std;

double real(const Complex& value) {
    return value.re;
}