#include "Complex.hpp"
using namespace std;

double imag(const Complex& value) {
    return value.im;
}